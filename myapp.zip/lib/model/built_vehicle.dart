library built_vehicle;

import 'package:built_value/built_value.dart';
part 'built_vehicle.g.dart';

abstract class BuiltVehicle
    implements Built<BuiltVehicle, BuiltVehicleBuilder> {
  String get type;
  String get brand;
  double get price;

  BuiltVehicle._();

  factory BuiltVehicle([void Function(BuiltVehicleBuilder) update]) =
      _$BuiltVehicle;
}
