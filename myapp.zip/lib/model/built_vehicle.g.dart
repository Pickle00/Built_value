// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'built_vehicle.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

class _$BuiltVehicle extends BuiltVehicle {
  @override
  final String type;
  @override
  final String brand;
  @override
  final double price;

  factory _$BuiltVehicle([void Function(BuiltVehicleBuilder)? updates]) =>
      (new BuiltVehicleBuilder()..update(updates))._build();

  _$BuiltVehicle._(
      {required this.type, required this.brand, required this.price})
      : super._() {
    BuiltValueNullFieldError.checkNotNull(type, r'BuiltVehicle', 'type');
    BuiltValueNullFieldError.checkNotNull(brand, r'BuiltVehicle', 'brand');
    BuiltValueNullFieldError.checkNotNull(price, r'BuiltVehicle', 'price');
  }

  @override
  BuiltVehicle rebuild(void Function(BuiltVehicleBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  BuiltVehicleBuilder toBuilder() => new BuiltVehicleBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is BuiltVehicle &&
        type == other.type &&
        brand == other.brand &&
        price == other.price;
  }

  @override
  int get hashCode {
    var _$hash = 0;
    _$hash = $jc(_$hash, type.hashCode);
    _$hash = $jc(_$hash, brand.hashCode);
    _$hash = $jc(_$hash, price.hashCode);
    _$hash = $jf(_$hash);
    return _$hash;
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'BuiltVehicle')
          ..add('type', type)
          ..add('brand', brand)
          ..add('price', price))
        .toString();
  }
}

class BuiltVehicleBuilder
    implements Builder<BuiltVehicle, BuiltVehicleBuilder> {
  _$BuiltVehicle? _$v;

  String? _type;
  String? get type => _$this._type;
  set type(String? type) => _$this._type = type;

  String? _brand;
  String? get brand => _$this._brand;
  set brand(String? brand) => _$this._brand = brand;

  double? _price;
  double? get price => _$this._price;
  set price(double? price) => _$this._price = price;

  BuiltVehicleBuilder();

  BuiltVehicleBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _type = $v.type;
      _brand = $v.brand;
      _price = $v.price;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(BuiltVehicle other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$BuiltVehicle;
  }

  @override
  void update(void Function(BuiltVehicleBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  BuiltVehicle build() => _build();

  _$BuiltVehicle _build() {
    final _$result = _$v ??
        new _$BuiltVehicle._(
            type: BuiltValueNullFieldError.checkNotNull(
                type, r'BuiltVehicle', 'type'),
            brand: BuiltValueNullFieldError.checkNotNull(
                brand, r'BuiltVehicle', 'brand'),
            price: BuiltValueNullFieldError.checkNotNull(
                price, r'BuiltVehicle', 'price'));
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
