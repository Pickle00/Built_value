import 'package:myapp/model/built_vehicle.dart';
// import 'package:myapp/model/built_vehicle.g.dart';

class CodeRunner {
  static BuiltVehicle runcode() {
    var car = BuiltVehicle(
      (b) => b
        ..type = 'car'
        ..brand = 'tesla'
        ..price = 10000,
    );
    return car;
  }
}
